var searchData=
[
  ['pointcompare',['PointCompare',['../class_point_compare.html',1,'']]]
];
