var searchData=
[
  ['victor',['victor',['../class_gameboard_single_player.html#a5d0c000ca4e7be5c649b21a10eede459',1,'GameboardSinglePlayer']]]
];
