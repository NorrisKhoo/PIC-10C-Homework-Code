var searchData=
[
  ['isvalid_5faircraft_5fcarrier',['isValid_aircraft_carrier',['../class_gameboard_single_player.html#abe0112f4181a0baf0a55ef3a4e4c1d92',1,'GameboardSinglePlayer']]],
  ['isvalid_5fbattleship',['isValid_battleship',['../class_gameboard_single_player.html#a355dca8c7f95305443e414bd731d2e96',1,'GameboardSinglePlayer']]],
  ['isvalid_5fcruiser',['isValid_cruiser',['../class_gameboard_single_player.html#a10f0a1c70ba80d21abe0270b93d54229',1,'GameboardSinglePlayer']]],
  ['isvalid_5fdestroyer',['isValid_destroyer',['../class_gameboard_single_player.html#a2402a772280961f322e0651d2360251d',1,'GameboardSinglePlayer']]],
  ['isvalid_5fsubmarine',['isValid_submarine',['../class_gameboard_single_player.html#aecdaea3f1317b22cd6bbd3ffa15108e0',1,'GameboardSinglePlayer']]]
];
