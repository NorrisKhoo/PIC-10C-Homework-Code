var searchData=
[
  ['_7egameboardsingleplayer',['~GameboardSinglePlayer',['../class_gameboard_single_player.html#ae06ec3c5ecf8e05e9adf0e752e6399c8',1,'GameboardSinglePlayer']]],
  ['_7emainwindow',['~MainWindow',['../class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]]
];
