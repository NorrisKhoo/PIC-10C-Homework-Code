var searchData=
[
  ['updatelocation',['updateLocation',['../class_gameboard_single_player.html#a4b67aa4e41f5177ed40facce0889bf04',1,'GameboardSinglePlayer']]]
];
