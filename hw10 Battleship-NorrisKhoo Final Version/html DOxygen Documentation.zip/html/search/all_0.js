var searchData=
[
  ['classic_5fgame_5fsingle_5fplayer_5fbegin',['classic_game_single_player_begin',['../class_main_window.html#a1e86d733f8f87edccbdea32fe8cb434d',1,'MainWindow']]],
  ['clear_5fopponent_5fboard',['clear_opponent_board',['../class_gameboard_single_player.html#a0ef6436099ffd19fb55895b353f2bf2e',1,'GameboardSinglePlayer']]],
  ['create_5fgray_5fbox',['create_gray_box',['../class_gameboard_single_player.html#aec33c3327beb51c1d8d2b3503b55250f',1,'GameboardSinglePlayer']]],
  ['create_5fwhite_5fbox',['create_white_box',['../class_gameboard_single_player.html#a826a3bbc2905c03b340792f4251a7b88',1,'GameboardSinglePlayer']]]
];
